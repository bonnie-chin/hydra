#ifndef _SUB_H_
#define _SUB_H_

enum class SubscriptionType { Regular, Test };

#endif