class InvalidValueException {};

class NoCardsToDraw {};

class OnlyReserveLeft {};

class JokerValueNotSet {};
